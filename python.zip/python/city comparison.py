import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Load Data
path = r'D:\Data Analytics\DESPROJECT\data.csv'
df = pd.read_csv(path)

# Bar Plot
if 'City' in df.columns:
    plt.figure(figsize=(12, 6))
    order = df.groupby('City')['ALLSKY_SFC_SW_DWN'].mean().sort_values(ascending=False).index
    sns.barplot(data=df, x='City', y='ALLSKY_SFC_SW_DWN', order=order, palette='viridis')
    plt.xticks(rotation=45)
    plt.title('Average Solar Energy Potential per City')
    plt.ylabel('Solar Radiation (kWh/m2/day)')
    
    print("Generating City Comparison Chart...")
    plt.show()