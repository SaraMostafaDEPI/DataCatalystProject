import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Load Data
path = r'D:\Data Analytics\DESPROJECT\data.csv'
df = pd.read_csv(path)

# Monthly Trends
if 'Month' in df.columns and 'City' in df.columns:
    plt.figure(figsize=(12, 7))
    sns.lineplot(data=df, x='Month', y='ALLSKY_SFC_SW_DWN', hue='City', marker='o', linewidth=2)
    plt.title('Monthly Solar Radiation Trends (Seasonal Analysis)')
    plt.grid(True, linestyle='--', alpha=0.6)
    plt.xticks(range(1, 13))
    plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
    
    print("Generating Monthly Trend Analysis...")
    plt.tight_layout()
    plt.show()