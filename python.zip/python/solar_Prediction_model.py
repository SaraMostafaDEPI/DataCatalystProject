import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor

# Load Data
path = r'D:\Data Analytics\DESPROJECT\data.csv'
df = pd.read_csv(path)

# Prepare Features (T2M=Temp, RH2M=Humidity, WS10M=Wind Speed)
X = df[['T2M', 'RH2M', 'WS10M']].dropna()
y = df.loc[X.index, 'ALLSKY_SFC_SW_DWN']

# Split & Train
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Results
score = model.score(X_test, y_test)
print("\n" + "="*45)
print("       SOLAR ENERGY PREDICTION RESULTS")
print("="*45)
print(f" FINAL MODEL ACCURACY (R2 SCORE): {score:.2%}")
print("="*45)
print("The model is now ready for real-time predictions.")