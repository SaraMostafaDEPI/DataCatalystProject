import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Load Data
path = r'D:\Data Analytics\DESPROJECT\data.csv'
df = pd.read_csv(path)

# Heatmap
cols = ['T2M', 'ALLSKY_SFC_SW_DWN', 'RH2M', 'WS10M']
plt.figure(figsize=(10, 8))
sns.heatmap(df[cols].corr(), annot=True, cmap='coolwarm', fmt=".2f")
plt.title('Correlation between Weather Factors & Solar Energy')

print("Generating Heatmap... Please close the window to finish.")
plt.show()